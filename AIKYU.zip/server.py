#!/usr/bin/env python3
"""
AIKYU — электронная валюта класса
Веб-приложение для учеников и учителя
"""

import os
import sqlite3
import hashlib
import secrets
from datetime import datetime, timedelta, timezone
from functools import wraps
from flask import (
    Flask, request, jsonify, session, redirect, url_for,
    render_template, g, send_from_directory
)

app = Flask(__name__, static_folder="static", template_folder="templates")
app.secret_key = secrets.token_hex(32)
app.config["SESSION_COOKIE_HTTPONLY"] = True
app.config["PERMANENT_SESSION_LIFETIME"] = timedelta(days=30)

DB_PATH = os.path.join(os.path.dirname(__file__), "aiky.db")

# ========== Database ==========

def get_db():
    if "db" not in g:
        g.db = sqlite3.connect(DB_PATH)
        g.db.row_factory = sqlite3.Row
        g.db.execute("PRAGMA foreign_keys = ON")
    return g.db

@app.teardown_appcontext
def close_db(e=None):
    db = g.pop("db", None)
    if db is not None:
        db.close()

def init_db():
    db = sqlite3.connect(DB_PATH)
    db.executescript("""
        CREATE TABLE IF NOT EXISTS users (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            name TEXT UNIQUE NOT NULL,
            pin_hash TEXT NOT NULL,
            role TEXT NOT NULL DEFAULT 'student',  -- student | teacher
            class INTEGER,                         -- 1, 2, 3 or NULL
            aiqu INTEGER NOT NULL DEFAULT 0,
            created_at TEXT NOT NULL
        );

        CREATE TABLE IF NOT EXISTS transactions (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            from_user_id INTEGER,
            to_user_id INTEGER NOT NULL,
            amount INTEGER NOT NULL,
            reason TEXT,
            created_at TEXT NOT NULL,
            FOREIGN KEY (from_user_id) REFERENCES users(id),
            FOREIGN KEY (to_user_id) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS homework (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            title TEXT NOT NULL,
            description TEXT,
            class INTEGER,           -- NULL = для всех
            created_by INTEGER NOT NULL,
            created_at TEXT NOT NULL,
            due_at TEXT,
            FOREIGN KEY (created_by) REFERENCES users(id)
        );

        CREATE TABLE IF NOT EXISTS messages (
            id INTEGER PRIMARY KEY AUTOINCREMENT,
            user_id INTEGER NOT NULL,
            text TEXT NOT NULL,
            created_at TEXT NOT NULL,
            FOREIGN KEY (user_id) REFERENCES users(id)
        );
    """)
    # Создаём учителя, если его ещё нет
    cur = db.execute("SELECT id FROM users WHERE role = 'teacher' LIMIT 1")
    if not cur.fetchone():
        pin_hash = hash_pin("1234")
        now = datetime.now(timezone.utc).isoformat()
        db.execute(
            "INSERT INTO users (name, pin_hash, role, class, aiqu, created_at) VALUES (?, ?, 'teacher', NULL, 0, ?)",
            ("Учитель", pin_hash, now)
        )
        db.commit()
        print(">>> Учитель создан: имя = Учитель, PIN = 1234")
    db.close()

def hash_pin(pin: str) -> str:
    return hashlib.sha256(pin.encode("utf-8")).hexdigest()

# ========== Auth helpers ==========

def login_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "Не авторизован"}), 401
        return f(*args, **kwargs)
    return decorated

def teacher_required(f):
    @wraps(f)
    def decorated(*args, **kwargs):
        if "user_id" not in session:
            return jsonify({"error": "Не авторизован"}), 401
        user = get_current_user()
        if not user or user["role"] != "teacher":
            return jsonify({"error": "Только для учителя"}), 403
        return f(*args, **kwargs)
    return decorated

def get_current_user():
    if "user_id" not in session:
        return None
    db = get_db()
    row = db.execute("SELECT * FROM users WHERE id = ?", (session["user_id"],)).fetchone()
    return dict(row) if row else None

# ========== Countdown helpers ==========

def next_lesson_time():
    """Следующий вторник или четверг в 18:40 (локальное время сервера)."""
    now = datetime.now()
    # 0=Mon ... 6=Sun ; нам нужны 1=Tue и 3=Thu
    target_weekdays = {1, 3}  # Tuesday, Thursday
    target_time = (18, 40)

    for days_ahead in range(0, 8):
        candidate = now + timedelta(days=days_ahead)
        if candidate.weekday() in target_weekdays:
            lesson = candidate.replace(hour=target_time[0], minute=target_time[1], second=0, microsecond=0)
            if lesson > now:
                return lesson
    # fallback
    return now + timedelta(days=1)

# ========== Routes: Pages ==========

@app.route("/")
def index():
    return render_template("index.html")

@app.route("/static/<path:path>")
def static_files(path):
    return send_from_directory("static", path)

# ========== API: Auth ==========

@app.route("/api/register", methods=["POST"])
def register():
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    pin = (data.get("pin") or "").strip()
    cls = data.get("class")

    if not name or len(name) < 2:
        return jsonify({"error": "Имя должно быть не короче 2 символов"}), 400
    if not pin or not pin.isdigit() or len(pin) != 4:
        return jsonify({"error": "PIN должен состоять из 4 цифр"}), 400
    if cls is not None:
        try:
            cls = int(cls)
            if cls not in (1, 2, 3):
                return jsonify({"error": "Класс должен быть 1, 2 или 3"}), 400
        except (TypeError, ValueError):
            return jsonify({"error": "Некорректный класс"}), 400

    db = get_db()
    existing = db.execute("SELECT id FROM users WHERE name = ?", (name,)).fetchone()
    if existing:
        return jsonify({"error": "Такое имя уже занято"}), 400

    now = datetime.now(timezone.utc).isoformat()
    try:
        cur = db.execute(
            "INSERT INTO users (name, pin_hash, role, class, aiqu, created_at) VALUES (?, ?, 'student', ?, 0, ?)",
            (name, hash_pin(pin), cls, now)
        )
        db.commit()
        user_id = cur.lastrowid
    except sqlite3.IntegrityError:
        return jsonify({"error": "Такое имя уже занято"}), 400

    session["user_id"] = user_id
    session.permanent = True
    user = get_current_user()
    return jsonify({"ok": True, "user": public_user(user)})

@app.route("/api/login", methods=["POST"])
def login():
    data = request.get_json() or {}
    name = (data.get("name") or "").strip()
    pin = (data.get("pin") or "").strip()

    if not name or not pin:
        return jsonify({"error": "Введите имя и PIN"}), 400

    db = get_db()
    row = db.execute("SELECT * FROM users WHERE name = ?", (name,)).fetchone()
    if not row or row["pin_hash"] != hash_pin(pin):
        return jsonify({"error": "Неверное имя или PIN"}), 401

    session["user_id"] = row["id"]
    session.permanent = True
    return jsonify({"ok": True, "user": public_user(dict(row))})

@app.route("/api/logout", methods=["POST"])
def logout():
    session.clear()
    return jsonify({"ok": True})

@app.route("/api/me")
def me():
    user = get_current_user()
    if not user:
        return jsonify({"user": None})
    return jsonify({"user": public_user(user)})

def public_user(u):
    return {
        "id": u["id"],
        "name": u["name"],
        "role": u["role"],
        "class": u["class"],
        "aiqu": u["aiqu"],
    }

# ========== API: Core data ==========

@app.route("/api/dashboard")
@login_required
def dashboard():
    user = get_current_user()
    db = get_db()

    # Leaderboard
    leaders = db.execute(
        "SELECT id, name, class, aiqu FROM users WHERE role = 'student' ORDER BY aiqu DESC, name ASC LIMIT 30"
    ).fetchall()
    leaders = [dict(r) for r in leaders]

    # Homework (для своего класса или общие)
    if user["role"] == "teacher":
        hw = db.execute(
            "SELECT h.*, u.name as author_name FROM homework h JOIN users u ON h.created_by = u.id ORDER BY h.created_at DESC LIMIT 20"
        ).fetchall()
    else:
        hw = db.execute(
            """SELECT h.*, u.name as author_name FROM homework h
               JOIN users u ON h.created_by = u.id
               WHERE h.class IS NULL OR h.class = ?
               ORDER BY h.created_at DESC LIMIT 20""",
            (user["class"],)
        ).fetchall()
    homework = [dict(r) for r in hw]

    # Recent chat
    msgs = db.execute(
        """SELECT m.id, m.text, m.created_at, u.name, u.role
           FROM messages m JOIN users u ON m.user_id = u.id
           ORDER BY m.id DESC LIMIT 50"""
    ).fetchall()
    messages = [dict(r) for r in reversed(msgs)]

    # Countdown
    lesson = next_lesson_time()
    now = datetime.now()
    seconds_left = max(0, int((lesson - now).total_seconds()))

    # Students list (for teacher)
    students = []
    if user["role"] == "teacher":
        rows = db.execute(
            "SELECT id, name, class, aiqu FROM users WHERE role = 'student' ORDER BY class, name"
        ).fetchall()
        students = [dict(r) for r in rows]

    return jsonify({
        "user": public_user(user),
        "leaders": leaders,
        "homework": homework,
        "messages": messages,
        "students": students,
        "next_lesson": lesson.isoformat(timespec="minutes"),
        "seconds_left": seconds_left,
    })

# ========== API: Chat ==========

@app.route("/api/chat", methods=["GET"])
@login_required
def get_chat():
    db = get_db()
    msgs = db.execute(
        """SELECT m.id, m.text, m.created_at, u.name, u.role
           FROM messages m JOIN users u ON m.user_id = u.id
           ORDER BY m.id DESC LIMIT 50"""
    ).fetchall()
    return jsonify({"messages": [dict(r) for r in reversed(msgs)]})

@app.route("/api/chat", methods=["POST"])
@login_required
def post_chat():
    data = request.get_json() or {}
    text = (data.get("text") or "").strip()
    if not text or len(text) > 500:
        return jsonify({"error": "Сообщение от 1 до 500 символов"}), 400

    user = get_current_user()
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    cur = db.execute(
        "INSERT INTO messages (user_id, text, created_at) VALUES (?, ?, ?)",
        (user["id"], text, now)
    )
    db.commit()
    return jsonify({
        "ok": True,
        "message": {
            "id": cur.lastrowid,
            "text": text,
            "created_at": now,
            "name": user["name"],
            "role": user["role"],
        }
    })

# ========== API: Teacher actions ==========

@app.route("/api/award", methods=["POST"])
@teacher_required
def award():
    data = request.get_json() or {}
    to_id = data.get("to_user_id")
    amount = data.get("amount")
    reason = (data.get("reason") or "").strip()[:200]

    try:
        to_id = int(to_id)
        amount = int(amount)
    except (TypeError, ValueError):
        return jsonify({"error": "Некорректные данные"}), 400

    if amount == 0:
        return jsonify({"error": "Сумма не может быть 0"}), 400
    if abs(amount) > 10000:
        return jsonify({"error": "Слишком большая сумма"}), 400

    db = get_db()
    student = db.execute("SELECT * FROM users WHERE id = ? AND role = 'student'", (to_id,)).fetchone()
    if not student:
        return jsonify({"error": "Ученик не найден"}), 404

    teacher = get_current_user()
    now = datetime.now(timezone.utc).isoformat()

    new_balance = student["aiqu"] + amount
    if new_balance < 0:
        return jsonify({"error": "Баланс не может стать отрицательным"}), 400

    db.execute("UPDATE users SET aiqu = ? WHERE id = ?", (new_balance, to_id))
    db.execute(
        "INSERT INTO transactions (from_user_id, to_user_id, amount, reason, created_at) VALUES (?, ?, ?, ?, ?)",
        (teacher["id"], to_id, amount, reason or None, now)
    )
    db.commit()

    return jsonify({"ok": True, "new_balance": new_balance, "student_name": student["name"]})

@app.route("/api/homework", methods=["POST"])
@teacher_required
def create_homework():
    data = request.get_json() or {}
    title = (data.get("title") or "").strip()
    description = (data.get("description") or "").strip()
    cls = data.get("class")  # None or 1/2/3
    due_at = data.get("due_at")  # optional ISO

    if not title or len(title) < 2:
        return jsonify({"error": "Название обязательно"}), 400

    if cls is not None and cls != "":
        try:
            cls = int(cls)
            if cls not in (1, 2, 3):
                return jsonify({"error": "Класс 1, 2 или 3"}), 400
        except (TypeError, ValueError):
            return jsonify({"error": "Некорректный класс"}), 400
    else:
        cls = None

    teacher = get_current_user()
    db = get_db()
    now = datetime.now(timezone.utc).isoformat()
    cur = db.execute(
        "INSERT INTO homework (title, description, class, created_by, created_at, due_at) VALUES (?, ?, ?, ?, ?, ?)",
        (title, description or None, cls, teacher["id"], now, due_at or None)
    )
    db.commit()
    return jsonify({"ok": True, "id": cur.lastrowid})

@app.route("/api/homework/<int:hw_id>", methods=["DELETE"])
@teacher_required
def delete_homework(hw_id):
    db = get_db()
    db.execute("DELETE FROM homework WHERE id = ?", (hw_id,))
    db.commit()
    return jsonify({"ok": True})

@app.route("/api/set-class", methods=["POST"])
@teacher_required
def set_class():
    data = request.get_json() or {}
    user_id = data.get("user_id")
    cls = data.get("class")

    try:
        user_id = int(user_id)
        if cls is None or cls == "":
            cls = None
        else:
            cls = int(cls)
            if cls not in (1, 2, 3):
                return jsonify({"error": "Класс 1, 2 или 3"}), 400
    except (TypeError, ValueError):
        return jsonify({"error": "Некорректные данные"}), 400

    db = get_db()
    student = db.execute("SELECT id FROM users WHERE id = ? AND role = 'student'", (user_id,)).fetchone()
    if not student:
        return jsonify({"error": "Ученик не найден"}), 404

    db.execute("UPDATE users SET class = ? WHERE id = ?", (cls, user_id))
    db.commit()
    return jsonify({"ok": True})

@app.route("/api/transactions")
@login_required
def transactions():
    user = get_current_user()
    db = get_db()
    if user["role"] == "teacher":
        rows = db.execute(
            """SELECT t.*, u.name as to_name
               FROM transactions t JOIN users u ON t.to_user_id = u.id
               ORDER BY t.id DESC LIMIT 50"""
        ).fetchall()
    else:
        rows = db.execute(
            """SELECT t.*, u.name as to_name
               FROM transactions t JOIN users u ON t.to_user_id = u.id
               WHERE t.to_user_id = ?
               ORDER BY t.id DESC LIMIT 30""",
            (user["id"],)
        ).fetchall()
    return jsonify({"transactions": [dict(r) for r in rows]})

# ========== Main ==========

if __name__ == "__main__":
    init_db()
    port = int(os.environ.get("PORT", os.environ.get("AIKY_PORT", 5050)))
    print(f"\n🚀 AIKYU запущен: http://0.0.0.0:{port}")
    print("   Учитель: имя = Учитель , PIN = 1234\n")
    app.run(host="0.0.0.0", port=port, debug=False)
